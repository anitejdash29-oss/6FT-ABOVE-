import java.util.ArrayList;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

// ════════════════════════════════════════════════════════════════════════════
//  WebpageAnalyzer.java
//  TruthGuard — AP Computer Science A Final Project
// ════════════════════════════════════════════════════════════════════════════
/**
 * WebpageAnalyzer — Basic Webpage Text Retrieval and Keyword Scanner
 *
 * This class connects to a website, reads its HTML source text line-by-line,
 * then scans the content for suspicious phrases, excessive punctuation,
 * and ALL-CAPS writing — all common signs of clickbait or misinformation.
 *
 * ── How it works (step-by-step) ─────────────────────────────────────────────
 *   1. fetchContent(url) opens a connection using java.net.URL + URLConnection
 *   2. A Scanner reads the HTML response line by line (up to 300 lines)
 *   3. The content is converted to lowercase for case-insensitive matching
 *   4. findSuspiciousPhrases() loops through a String[] and checks each phrase
 *   5. countExclamationMarks() loops character-by-character to count "!"
 *   6. hasExcessiveCaps() checks for ALL-CAPS words in the raw text
 *   7. computeScoreAdjustment() totals up the penalties
 *
 * ── AP CSA Concepts demonstrated ────────────────────────────────────────────
 *  ✦ Arrays         : String[] suspiciousPhrases — fixed keyword list
 *  ✦ ArrayLists     : ArrayList<String> to collect matched phrases
 *  ✦ Loops          : for loops over arrays and characters
 *  ✦ Conditionals   : if/else to apply each scoring penalty
 *  ✦ Exception handling : try/catch prevents crashes on bad URLs or timeouts
 *  ✦ String methods : toLowerCase(), contains(), split(), length(), charAt()
 *  ✦ Methods        : each responsibility is its own clearly-named method
 *  ✦ Encapsulation  : array is private; all access through public methods
 * ────────────────────────────────────────────────────────────────────────────
 */
public class WebpageAnalyzer {

    // ── Array: suspicious phrases (AP CSA array requirement) ─────────────────
    //
    //  WHY an array (not ArrayList)?
    //  → This list is fixed at compile time — it never changes while the
    //    program is running. Arrays are the right choice for fixed-size data.
    //
    //  These phrases are common in low-credibility, clickbait, and
    //  misinformation articles. Their presence in page content lowers the score.
    //
    private String[] suspiciousPhrases = {
        "breaking",                         // urgent/sensational tone
        "shocking",                         // emotional manipulation
        "you won't believe",               // classic clickbait opener
        "doctors hate",                    // fake medical clickbait
        "miracle cure",                    // unverified health claim
        "100% guaranteed",                 // unrealistic promise
        "click here now",                  // pressure language
        "secret",                          // implies hidden truth
        "hidden truth",                    // conspiracy framing
        "they don't want you to know",    // us-vs-them framing
        "censored",                        // content suppression claim
        "banned",                          // content suppression claim
        "exposed",                         // sensational language
        "wake up",                         // conspiracy call-to-action
        "must see",                        // manufactured urgency
        "share before deleted",            // viral misinformation tactic
        "mainstream media lies"            // institutional distrust phrase
    };

    // Maximum lines to read from a webpage (prevents reading huge pages slowly)
    private static final int MAX_LINES = 300;

    // Connection timeout in milliseconds (5 seconds)
    private static final int TIMEOUT_MS = 5000;

    // ── Constructor ──────────────────────────────────────────────────────────
    /**
     * Default constructor.
     * The suspiciousPhrases array is initialized with the declaration above.
     */
    public WebpageAnalyzer() {
        // Nothing extra needed — array initialized at declaration
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 1: FETCH WEBPAGE CONTENT
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Connects to a URL and reads its HTML source text line-by-line.
     *
     * Uses only AP CSA-appropriate Java classes:
     *   - java.net.URL       : represents the web address
     *   - java.net.URLConnection : opens the connection with timeout settings
     *   - java.util.Scanner  : reads lines from the response stream
     *   - StringBuilder      : efficiently builds the full content string
     *
     * Handles errors with try/catch — the method never crashes.
     * Returns an empty string if the URL is unreachable or times out.
     *
     * @param siteUrl  the full URL to fetch (e.g. "https://example.com")
     * @return         the raw HTML content as a single lowercase string,
     *                 or "" if the page could not be fetched
     */
    public String fetchContent(String siteUrl) {
        // try/catch: handles broken URLs, timeouts, connection refused, etc.
        try {
            // Step 1a: Create a URL object from the string
            URL url = new URL(siteUrl);

            // Step 1b: Open a connection with timeout settings
            //   setConnectTimeout: how long to wait to establish a connection
            //   setReadTimeout   : how long to wait while reading the response
            URLConnection connection = url.openConnection();
            connection.setConnectTimeout(TIMEOUT_MS);  // 5 seconds to connect
            connection.setReadTimeout(TIMEOUT_MS);     // 5 seconds to read
            // Identify as a browser so most sites don't block us
            connection.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (compatible; TruthGuard/1.0)");

            // Step 1c: Use Scanner to read the response line-by-line
            //   This is the same Scanner class used for keyboard input!
            Scanner pageScanner = new Scanner(connection.getInputStream());
            StringBuilder content = new StringBuilder();
            int lineCount = 0; // counter to cap how many lines we read

            // while loop: read lines until end-of-stream or line limit
            while (pageScanner.hasNextLine() && lineCount < MAX_LINES) {
                String line = pageScanner.nextLine();
                // Convert to lowercase so our phrase matching is case-insensitive
                content.append(line.toLowerCase()).append(" ");
                lineCount++;
            }

            pageScanner.close(); // always close the Scanner when done

            return content.toString(); // return the full collected content

        } catch (Exception e) {
            // ANY error → return empty string instead of crashing
            // Possible errors: MalformedURLException, IOException, SocketTimeoutException
            System.err.println("[WebpageAnalyzer] Could not fetch page: " + e.getMessage());
            return ""; // empty string signals "page not fetched"
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 2: FIND SUSPICIOUS PHRASES
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Loops through the suspiciousPhrases array and checks whether each
     * phrase appears anywhere in the page content.
     *
     * Uses:
     *   ✦ for loop over the String[] array (AP CSA array requirement)
     *   ✦ String.contains() for substring matching
     *   ✦ ArrayList to collect the matched phrases
     *
     * @param content  the fetched page text (already lowercased)
     * @return         ArrayList of matched suspicious phrases (may be empty)
     */
    public ArrayList<String> findSuspiciousPhrases(String content) {
        // ArrayList: dynamic size — we don't know how many phrases will match
        ArrayList<String> matched = new ArrayList<String>();

        // Conditional: nothing to scan if no content was fetched
        if (content.isEmpty()) {
            return matched; // return empty list
        }

        // For loop: traverse the entire suspiciousPhrases array by index
        for (int i = 0; i < suspiciousPhrases.length; i++) {
            String phrase = suspiciousPhrases[i];

            // String.contains() checks if the phrase appears ANYWHERE in content
            if (content.contains(phrase)) {
                matched.add(phrase); // add this phrase to our findings
            }
        }

        return matched; // return the list of all matched phrases
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 3: COUNT EXCLAMATION MARKS
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Counts how many exclamation marks ("!") appear in the content.
     * Legitimate articles rarely use many exclamation marks.
     * Excessive use (>5) is a signal of clickbait or sensationalism.
     *
     * Uses:
     *   ✦ for loop with charAt() — character-by-character traversal (AP CSA)
     *   ✦ char comparison
     *
     * @param content  the fetched page text
     * @return         the total count of "!" characters found
     */
    public int countExclamationMarks(String content) {
        int count = 0; // accumulator starts at 0

        // For loop: examine each character one at a time
        // This demonstrates character-level string processing (AP CSA String unit)
        for (int i = 0; i < content.length(); i++) {
            if (content.charAt(i) == '!') {
                count++; // found one — increment accumulator
            }
        }

        return count; // total exclamation marks found
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 4: DETECT ALL-CAPS WRITING
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Checks whether the page contains excessive ALL-CAPS words.
     * Headlines written entirely in uppercase are a common clickbait pattern.
     *
     * How it works:
     *   1. Split the content into individual words using split()
     *   2. Loop through each word
     *   3. Count words that are ALL CAPS and at least 4 letters long
     *   4. If more than 5 such words are found, flag as excessive
     *
     * Uses:
     *   ✦ String.split() — divides string into an array of words
     *   ✦ for loop over String[] array
     *   ✦ String methods: equals(), toUpperCase(), length()
     *
     * @param content  the fetched page text
     * @return         true if excessive ALL-CAPS writing is detected
     */
    public boolean hasExcessiveCaps(String content) {
        if (content.isEmpty()) {
            return false;
        }

        // Split the content into an array of words (AP CSA array usage)
        String[] words = content.split("\\s+"); // \\s+ matches any whitespace
        int capsWordCount = 0; // counts how many ALL-CAPS words we find

        // For loop: check each word
        for (int i = 0; i < words.length; i++) {
            String word = words[i];

            // Only check words that are at least 4 letters long
            // (short words like "I", "OK", "GO" are commonly capitalized)
            if (word.length() >= 4) {
                // Check if the word is entirely uppercase letters (A-Z only)
                // word.equals(word.toUpperCase()) → true if all letters are caps
                // word.matches("[A-Z]+") → confirms it contains only letters
                if (word.equals(word.toUpperCase()) && word.matches("[A-Z]+")) {
                    capsWordCount++;
                }
            }
        }

        // Conditional: more than 5 all-caps words → flag as excessive
        return capsWordCount > 5;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 5: COMPUTE SCORE ADJUSTMENT
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Calculates the total score penalty based on content analysis findings.
     *
     * Scoring rules:
     *   -3 per suspicious phrase found in content
     *   -5 if more than 5 exclamation marks detected
     *   -10 if excessive ALL-CAPS writing detected
     *
     * The result is always <= 0 (content analysis only applies penalties).
     *
     * @param matchedPhrases   the list of suspicious phrases found
     * @param exclamationCount the total "!" count in the content
     * @param hasCaps          whether excessive ALL-CAPS was detected
     * @return                 the score penalty (0 or negative)
     */
    public int computeScoreAdjustment(ArrayList<String> matchedPhrases,
                                       int exclamationCount,
                                       boolean hasCaps) {
        int adjustment = 0; // starts at 0

        // Penalty: -3 for every suspicious phrase found
        // matchedPhrases.size() tells us how many matched
        adjustment -= matchedPhrases.size() * 3;

        // Conditional: excessive exclamation marks
        if (exclamationCount > 5) {
            adjustment -= 5; // -5 for excessive "!!!!" usage
        }

        // Conditional: excessive ALL-CAPS writing
        if (hasCaps) {
            adjustment -= 10; // -10 for ALL-CAPS headlines
        }

        return adjustment; // always 0 or negative
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 6: FULL ANALYSIS (orchestrates steps 1–5)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Runs the complete content analysis pipeline on a WebsiteSource object.
     * Fetches the page, scans it, and applies results directly to the site.
     *
     * This is the main entry point called by CredibilityEngine.
     *
     * What it does:
     *   1. Fetch the page content
     *   2. Find suspicious phrases
     *   3. Count exclamation marks
     *   4. Check for ALL-CAPS writing
     *   5. Compute total score adjustment
     *   6. Apply warnings and adjusted score back to the WebsiteSource object
     *
     * @param site  the WebsiteSource object to analyze and update
     */
    public void analyze(WebsiteSource site) {
        String siteUrl = site.getUrl();

        System.err.println("[WebpageAnalyzer] Fetching content from: " + siteUrl);

        // Step 1: Fetch the page HTML
        String content = fetchContent(siteUrl);

        // Conditional: if fetch failed, mark as not analyzed and exit
        if (content.isEmpty()) {
            site.setContentAnalyzed(false);
            System.err.println("[WebpageAnalyzer] Could not retrieve page content.");
            return;
        }

        System.err.println("[WebpageAnalyzer] Page fetched. Scanning content...");

        // Step 2: Find suspicious phrases
        ArrayList<String> warnings = findSuspiciousPhrases(content);

        // Step 3: Count exclamation marks
        int exclamations = countExclamationMarks(content);

        // Step 4: Check for ALL-CAPS
        boolean hasCaps = hasExcessiveCaps(content);

        // Step 5: Compute score adjustment
        int adjustment = computeScoreAdjustment(warnings, exclamations, hasCaps);

        // Step 6: Apply results to the WebsiteSource object

        // Store warnings in the site object (for display in results)
        site.setContentWarnings(warnings);
        site.setContentAnalyzed(true);

        // Apply score adjustment (clamped to 0–100)
        if (adjustment < 0) {
            int current = site.getCredibilityScore();
            int adjusted = Math.max(0, current + adjustment); // never below 0
            site.setCredibilityScore(adjusted);
            site.addFlag("Content scan: " + warnings.size()
                    + " suspicious phrase(s) found (" + adjustment + ")");
        }

        // Add specific additional flags for exclamations and caps
        if (exclamations > 5) {
            site.addFlag("Excessive exclamation marks in page content (-5)");
        }
        if (hasCaps) {
            site.addFlag("ALL-CAPS writing detected in page content (-10)");
        }

        System.err.println("[WebpageAnalyzer] Done. Adjustment: " + adjustment
                + ", Warnings: " + warnings.size());
    }

    // ── Getter: return the phrase list (for testing / display) ───────────────
    /**
     * Returns the array of suspicious phrases.
     * Useful for printing the list in the console menu.
     *
     * @return the suspiciousPhrases String array
     */
    public String[] getSuspiciousPhrases() {
        return suspiciousPhrases;
    }
}
