import java.util.ArrayList;

// ════════════════════════════════════════════════════════════════════════════
//  CredibilityEngine.java
//  TruthGuard — AP Computer Science A Final Project
// ════════════════════════════════════════════════════════════════════════════
/**
 * CredibilityEngine — Core Analysis Engine
 *
 * This is the central class of TruthGuard. It classifies URLs, invokes the
 * correct scoring subclass (POLYMORPHISM), maintains a session history
 * (ArrayList data structure), and provides search, filter, and statistics.
 *
 * ── AP CSA Concepts in this class ──────────────────────────────────────────
 *  ✦ Classes & Objects   : Engine is instantiated in Main and used throughout
 *  ✦ Polymorphism        : analyze() stores any WebsiteSource subclass
 *  ✦ Abstraction         : callers use analyze(); internal logic is hidden
 *  ✦ ArrayList           : analysisHistory stores all checked WebsiteSources
 *  ✦ Loops               : for-loops traverse history for stats/search/filter
 *  ✦ Conditionals        : TLD checks to classify URL into correct subclass
 *  ✦ Methods             : all have parameter types and meaningful return values
 * ────────────────────────────────────────────────────────────────────────────
 */
public class CredibilityEngine {

    // ── Data Structure: ArrayList (AP CSA requirement) ───────────────────────
    //
    //  WHY ArrayList (not an array)?
    //  → We don't know how many URLs the user will check at compile time.
    //  → ArrayList grows dynamically; arrays have a fixed length.
    //  → ArrayList<WebsiteSource> can hold TrustedSource, SuspiciousSource,
    //    OR NeutralSource objects — demonstrating polymorphism in storage.
    //
    private ArrayList<WebsiteSource> analysisHistory;

    // ── Constructor ──────────────────────────────────────────────────────────
    /**
     * Initializes the engine with an empty analysis history.
     * Each new program run starts fresh (session-level history).
     */
    public CredibilityEngine() {
        analysisHistory = new ArrayList<WebsiteSource>();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CORE ANALYSIS  (Polymorphism + Abstraction)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Analyzes a single URL end-to-end:
     *   Step 1 → Classify URL into the correct WebsiteSource subclass
     *   Step 2 → Call calculateCredibility() — POLYMORPHIC DISPATCH
     *   Step 3 → Run WebpageAnalyzer on the live page content
     *   Step 4 → Store result in analysisHistory ArrayList
     *   Step 5 → Return the populated WebsiteSource object
     *
     * KEY POLYMORPHISM POINT:
     *   The local variable 'site' is declared as WebsiteSource (the abstract
     *   parent type), but at runtime it holds a TrustedSource, SuspiciousSource,
     *   or NeutralSource. When site.calculateCredibility() is called, Java
     *   automatically routes to the correct subclass's version of that method.
     *
     * @param url  the URL string to analyze (expected to start with http/https)
     * @return     the WebsiteSource object with score and flags fully populated
     */
    public WebsiteSource analyze(String url) {
        String lower = url.toLowerCase(); // normalize for case-insensitive checks

        // ── Step 1: Classify URL → pick correct subclass ──────────────────
        //
        //  POLYMORPHISM: 'site' is WebsiteSource (parent type) but holds
        //  a subclass object. This is the "parent reference = child object"
        //  pattern required by the AP CSA polymorphism concept.
        //
        WebsiteSource site;

        if (isTrustedDomain(lower)) {
            // .gov → Government; .edu → Academic Institution
            String verifier = lower.contains(".gov") ? "Government" : "Academic Institution";
            site = new TrustedSource(url, verifier);

        } else if (isSuspiciousDomain(lower)) {
            // Red-flag TLD or suspicious keyword in URL
            site = new SuspiciousSource(url, "Suspicious domain pattern or TLD detected");

        } else {
            // All other URLs: start neutral, apply both +/- rules
            site = new NeutralSource(url);
        }

        // ── Step 2: Polymorphic dispatch ──────────────────────────────────
        //
        //  Java resolves which calculateCredibility() to call at RUNTIME,
        //  not compile time. TrustedSource's version → bonuses only;
        //  SuspiciousSource's version → penalties + keyword scan;
        //  NeutralSource's version → balanced bonuses and penalties.
        //
        site.calculateCredibility();

        // ── Step 3: Webpage content analysis (WebpageAnalyzer) ───────────
        //
        //  After URL-based scoring, WebpageAnalyzer fetches the actual page
        //  HTML and scans it for suspicious phrases, ALL-CAPS writing, and
        //  excessive "!!!". It updates the site's score and contentWarnings
        //  directly via setters — encapsulation in action.
        //
        //  If the page is unreachable or times out, analyze() skips silently.
        //
        WebpageAnalyzer webAnalyzer = new WebpageAnalyzer();
        webAnalyzer.analyze(site); // adjusts score + populates contentWarnings

        // ── Step 4: Store result in ArrayList ─────────────────────────────
        analysisHistory.add(site);

        // ── Step 5: Return populated site object ─────────────────────────
        return site;
    }

    // ── Private helper: trusted TLD check ───────────────────────────────────
    /**
     * Returns true if the URL belongs to a trusted top-level domain.
     * Used internally by analyze() to select the TrustedSource subclass.
     *
     * @param lowerUrl  the URL already converted to lowercase
     * @return          true if .gov or .edu is present
     */
    private boolean isTrustedDomain(String lowerUrl) {
        // Conditional: check both trusted TLDs with OR
        return lowerUrl.contains(".gov") || lowerUrl.contains(".edu");
    }

    // ── Private helper: suspicious domain check ──────────────────────────────
    /**
     * Returns true if the URL has suspicious characteristics:
     * a red-flag TLD (.xyz, .tk, .ml, .cf) OR a suspicious keyword in the URL.
     * Uses KeywordScanner (array-based) to detect keyword matches.
     *
     * @param lowerUrl  the URL already converted to lowercase
     * @return          true if any suspicious pattern is found
     */
    private boolean isSuspiciousDomain(String lowerUrl) {
        // Check 1: known low-credibility TLDs (conditional chain)
        if (lowerUrl.contains(".xyz") || lowerUrl.contains(".tk")
                || lowerUrl.contains(".ml") || lowerUrl.contains(".cf")) {
            return true;
        }

        // Check 2: suspicious keywords embedded in the URL itself
        // KeywordScanner.countKeywordMatches() loops through a String array
        KeywordScanner scanner = new KeywordScanner();
        if (scanner.countKeywordMatches(lowerUrl) > 0) {
            return true;
        }

        return false; // no suspicious indicators found
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HISTORY MANAGEMENT
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Returns the full session analysis history.
     * Used externally to iterate over all checked WebsiteSource objects.
     *
     * @return  ArrayList of all WebsiteSource objects analyzed this session
     */
    public ArrayList<WebsiteSource> getHistory() {
        return analysisHistory;
    }

    /**
     * Prints all session history entries to the console.
     *
     * Demonstrates:
     *   ✦ ArrayList traversal (for loop with index)
     *   ✦ Polymorphism: toString() on each WebsiteSource calls the correct
     *     subclass's toString() version via inherited method
     */
    public void printHistory() {
        // Conditional: handle empty case gracefully
        if (analysisHistory.isEmpty()) {
            System.out.println("  No URLs analyzed yet this session.");
            return;
        }

        System.out.println("\n========== Session Analysis History ==========");

        // For loop: traverse ArrayList using index (AP CSA loop requirement)
        for (int i = 0; i < analysisHistory.size(); i++) {
            System.out.println("\n  [Entry " + (i + 1) + " of " + analysisHistory.size() + "]");
            // toString() call is polymorphic: correct subclass method runs
            System.out.println(analysisHistory.get(i).toString());
            System.out.println("  ──────────────────────────────────────────");
        }

        System.out.println("==============================================");
    }

    /**
     * Returns the count of URLs analyzed this session.
     *
     * @return  the size of the analysisHistory ArrayList
     */
    public int getAnalysisCount() {
        return analysisHistory.size();
    }

    /**
     * Clears the session history ArrayList.
     * Does not affect the persistent history.txt file.
     */
    public void clearHistory() {
        analysisHistory.clear();
        System.out.println("  Session history cleared.");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STATISTICS DASHBOARD  (Loops + Conditionals + Data Analysis)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Prints a statistics dashboard for the current session.
     *
     * Statistics computed:
     *   - Total URLs checked
     *   - Average credibility score
     *   - Breakdown by rating tier (Highly Credible / Mostly / Questionable / Suspicious)
     *   - Breakdown by source type (TrustedSource / NeutralSource / SuspiciousSource)
     *   - Most flagged issue
     *
     * Demonstrates:
     *   ✦ ArrayList loop (for loop)
     *   ✦ Accumulators (running totals, counters)
     *   ✦ Conditionals (if-else chains to categorize scores)
     *   ✦ instanceof operator (checks actual subclass type at runtime)
     */
    public void printStats() {
        // Conditional: nothing to show yet
        if (analysisHistory.isEmpty()) {
            System.out.println("  No data yet. Check at least one URL first.");
            return;
        }

        // ── Accumulators ─────────────────────────────────────────────────
        int total      = analysisHistory.size();
        int totalScore = 0;  // sum for computing average

        // Rating tier counters
        int highCount = 0;  // score 80–100
        int goodCount = 0;  // score 60–79
        int midCount  = 0;  // score 40–59
        int lowCount  = 0;  // score below 40

        // Source type counters
        int trustedCount    = 0;
        int neutralCount    = 0;
        int suspiciousCount = 0;

        // Most common flag accumulator
        String mostCommonFlag = "";
        int mostCommonFlagCount = 0;
        java.util.HashMap<String, Integer> flagCounts = new java.util.HashMap<>();

        // ── For loop: traverse entire history ArrayList ──────────────────
        for (int i = 0; i < analysisHistory.size(); i++) {
            WebsiteSource site = analysisHistory.get(i);
            int score = site.getCredibilityScore();
            totalScore += score; // accumulate for average

            // Conditional: categorize by score range
            if (score >= 80) {
                highCount++;
            } else if (score >= 60) {
                goodCount++;
            } else if (score >= 40) {
                midCount++;
            } else {
                lowCount++;
            }

            // instanceof: check actual runtime type (polymorphism awareness)
            if (site instanceof TrustedSource) {
                trustedCount++;
            } else if (site instanceof SuspiciousSource) {
                suspiciousCount++;
            } else {
                neutralCount++;
            }

            // Count flag occurrences for "most common issue" stat
            ArrayList<String> flags = site.getFlags();
            for (int j = 0; j < flags.size(); j++) {
                String flag = flags.get(j);
                String key = flag.split("\\(")[0].trim();
                int prev = flagCounts.getOrDefault(key, 0);
                flagCounts.put(key, prev + 1);
                if (prev + 1 > mostCommonFlagCount) {
                    mostCommonFlagCount = prev + 1;
                    mostCommonFlag = key;
                }
            }
        }

        // Compute average (integer division — AP CSA arithmetic)
        int avgScore = (total > 0) ? totalScore / total : 0;

        // ── Print the dashboard ──────────────────────────────────────────
        System.out.println("\n╔══════════════════════════════════════════╗");
        System.out.println("║        STATISTICS DASHBOARD              ║");
        System.out.println("╚══════════════════════════════════════════╝");
        System.out.println();
        System.out.println("  Total URLs Checked   : " + total);
        System.out.println("  Average Score        : " + avgScore + " / 100");
        System.out.println();
        System.out.println("  ── By Rating ──────────────────────────────");
        System.out.printf("  %-20s : %d%n", "Highly Credible (80+)", highCount);
        System.out.printf("  %-20s : %d%n", "Mostly Credible (60+)", goodCount);
        System.out.printf("  %-20s : %d%n", "Questionable   (40+)", midCount);
        System.out.printf("  %-20s : %d%n", "Suspicious     (<40)", lowCount);
        System.out.println();
        System.out.println("  ── By Source Type ─────────────────────────");
        System.out.printf("  %-20s : %d%n", "TrustedSource",    trustedCount);
        System.out.printf("  %-20s : %d%n", "NeutralSource",    neutralCount);
        System.out.printf("  %-20s : %d%n", "SuspiciousSource", suspiciousCount);
        System.out.println();
        if (!mostCommonFlag.isEmpty()) {
            System.out.println("  Most Common Flag     : " + mostCommonFlag
                    + " (" + mostCommonFlagCount + "x)");
        }
        System.out.println("════════════════════════════════════════════");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  SEARCH FEATURE  (String matching + ArrayList + Loop)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Searches the session history for URLs containing the given query string.
     * Case-insensitive partial match (e.g. "gov" matches "https://cdc.gov/flu").
     *
     * Demonstrates:
     *   ✦ ArrayList traversal with for loop
     *   ✦ String.contains() for partial matching
     *   ✦ Building a filtered ArrayList as a return value
     *
     * @param query  the search keyword to look for within each URL
     * @return       ArrayList of matching WebsiteSource objects
     */
    public ArrayList<WebsiteSource> searchHistory(String query) {
        ArrayList<WebsiteSource> results = new ArrayList<WebsiteSource>();
        String lowerQuery = query.toLowerCase(); // normalize for comparison

        // For loop: check every URL in history
        for (int i = 0; i < analysisHistory.size(); i++) {
            WebsiteSource site = analysisHistory.get(i);
            // Conditional: add to results if URL contains the query
            if (site.getUrl().toLowerCase().contains(lowerQuery)) {
                results.add(site);
            }
        }

        return results; // may be empty if no matches
    }

    /**
     * Prints the results of a history search to the console.
     *
     * @param query  the search keyword entered by the user
     */
    public void printSearchResults(String query) {
        ArrayList<WebsiteSource> results = searchHistory(query);

        System.out.println("\n=== Search Results for: \"" + query + "\" ===");

        if (results.isEmpty()) {
            System.out.println("  No matching URLs found in session history.");
        } else {
            System.out.println("  Found " + results.size() + " match(es):\n");
            for (int i = 0; i < results.size(); i++) {
                System.out.println("  [" + (i + 1) + "] " + results.get(i).toString());
                System.out.println("  ─────────────────────────────────────");
            }
        }
        System.out.println("=========================================");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  FILTER FEATURE  (Conditional filtering + ArrayList + Loop)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Filters the session history by credibility rating tier.
     *
     * Valid filter values: "credible", "questionable", "suspicious"
     *   - "credible"     → score >= 60
     *   - "questionable" → score 40–59
     *   - "suspicious"   → score < 40
     *
     * Demonstrates:
     *   ✦ ArrayList traversal with for loop
     *   ✦ Conditional branching on score ranges
     *   ✦ Returning a filtered ArrayList
     *
     * @param filter  the rating category to keep (case-insensitive)
     * @return        ArrayList of WebsiteSource objects matching the filter
     */
    public ArrayList<WebsiteSource> filterByRating(String filter) {
        ArrayList<WebsiteSource> results = new ArrayList<WebsiteSource>();
        String lowerFilter = filter.toLowerCase();

        // For loop: examine each entry in history
        for (int i = 0; i < analysisHistory.size(); i++) {
            WebsiteSource site = analysisHistory.get(i);
            int score = site.getCredibilityScore();

            boolean include = false;

            if (lowerFilter.equals("credible") && score >= 60) {
                include = true;
            } else if (lowerFilter.equals("questionable")
                    && score >= 40 && score < 60) {
                include = true;
            } else if (lowerFilter.equals("suspicious") && score < 40) {
                include = true;
            }

            if (include) {
                results.add(site);
            }
        }

        return results;
    }

    /**
     * Prints filtered history results to the console.
     *
     * @param filter  the rating category chosen by the user
     */
    public void printFilteredHistory(String filter) {
        ArrayList<WebsiteSource> results = filterByRating(filter);

        System.out.println("\n=== Filtered Results: " + filter.toUpperCase() + " ===");

        if (results.isEmpty()) {
            System.out.println("  No URLs in this session match the filter: " + filter);
        } else {
            System.out.println("  Showing " + results.size() + " result(s):\n");
            for (int i = 0; i < results.size(); i++) {
                System.out.println("  [" + (i + 1) + "] " + results.get(i).toString());
                System.out.println("  ─────────────────────────────────────");
            }
        }
        System.out.println("=========================================");
    }
}
