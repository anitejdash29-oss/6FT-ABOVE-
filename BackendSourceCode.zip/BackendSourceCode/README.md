# TruthGuard — Backend Source Code
### AP Computer Science A Final Project

A Java credibility-scoring engine that analyzes website URLs for signs of misinformation. Enter a URL — the engine scores it 0–100 and explains every scoring decision.

---

## Folder Structure

```
BackendSourceCode/
├── Main.java                  ← Entry point; interactive menu + JSON CLI mode
│
├── core/
│   ├── CredibilityEngine.java ← Central analysis engine; history; stats; search; filter
│   └── WebpageAnalyzer.java   ← Fetches live page HTML; scans for suspicious phrases
│
├── models/
│   ├── WebsiteSource.java     ← ABSTRACT base class (Abstraction + Encapsulation)
│   ├── TrustedSource.java     ← Subclass: .gov / .edu domains (+30/+25 bonus)
│   ├── SuspiciousSource.java  ← Subclass: .xyz, keywords, no-HTTPS (penalties)
│   └── NeutralSource.java     ← Subclass: balanced positive + negative rules
│
├── utils/
│   ├── FileManager.java       ← Reads/writes history.txt and history-api.json
│   ├── InputValidator.java    ← Validates URL format + menu choices
│   └── KeywordScanner.java    ← Scans URLs for 15 suspicious keywords (String array)
│
├── data/
│   ├── suspicious_keywords.txt ← Reference list of all keywords and phrases
│   └── checked_history.txt     ← Sample history file (appended per run in live app)
│
└── tests/
    └── TestCases.txt           ← All 10 test cases documented with expected results
```

---

## How to Compile and Run

**Prerequisites:** Java 8 or higher installed (`java -version` to check)

```bash
# 1. Create the output directory for compiled .class files
mkdir -p out

# 2. Compile ALL .java files — order does not matter, javac resolves dependencies
javac -d out Main.java core/*.java models/*.java utils/*.java

# 3. Run the interactive console menu
java -cp out Main

# 4. Or run a single URL check (JSON output mode — used by the web API)
java -cp out Main --check https://www.cdc.gov/flu
```

---

## Class Descriptions

### `Main.java`
The program entry point. Manages an 11-option interactive console menu (while loop) and a non-interactive JSON CLI mode (`--check <url>`) used by the Node.js web API bridge. Instantiates and connects all other classes.

### `core/CredibilityEngine.java`
The brain of TruthGuard. `analyze(url)` classifies the URL into the correct subclass, calls the polymorphic `calculateCredibility()` method, runs `WebpageAnalyzer` on the live page, stores the result in an `ArrayList<WebsiteSource>`, and returns the populated object. Also provides `searchHistory()`, `filterByRating()`, and `printStats()`.

### `core/WebpageAnalyzer.java`
After URL-based scoring, this class fetches the actual page HTML using `java.net.URL` and `URLConnection`. It scans the content for 17 suspicious phrases (stored in a `String[]` array), counts `!` marks, and detects ALL-CAPS writing. Applies score penalties (-3/phrase, -5 for excessive `!`, -10 for ALL-CAPS) and populates the site's `contentWarnings` list.

### `models/WebsiteSource.java` — Abstract Base Class
Defines all shared fields (`url`, `credibilityScore`, `flags`, `contentWarnings`, `contentAnalyzed`) with private access (Encapsulation). Declares `calculateCredibility()` as abstract — forcing each subclass to implement its own version (Polymorphism). Includes `toJson()` for JSON serialization (no external library) and `toString()` for console display.

### `models/TrustedSource.java` — Subclass
Extends `WebsiteSource`. Overrides `calculateCredibility()` to apply trust bonuses: +30 for `.gov`, +25 for `.edu`, +10 for `.org`, +10 for HTTPS. Score capped at 100.

### `models/SuspiciousSource.java` — Subclass
Extends `WebsiteSource`. Overrides `calculateCredibility()` to apply penalties: -20 for `.xyz`, -5 for no HTTPS, -10 for excessive URL symbols, -5 per keyword found by `KeywordScanner`. Uses a `for` loop to count characters. Score floored at 0.

### `models/NeutralSource.java` — Subclass
Extends `WebsiteSource`. Overrides `calculateCredibility()` with a balanced ruleset applying both bonuses and penalties. Most URLs fall into this category.

### `utils/FileManager.java`
Handles persistent storage using `PrintWriter`, `FileWriter`, and `Scanner` (AP CSA file I/O). Writes human-readable `.txt` history and machine-readable NDJSON history (`history-api.json`). All operations wrapped in `try/catch`.

### `utils/InputValidator.java`
Validates user input before it reaches the engine. Prevents crashes from null input, non-URL strings, wrong protocols, and non-numeric menu choices. Uses `String` methods and `try/catch` around `Integer.parseInt()`.

### `utils/KeywordScanner.java`
Stores 15 suspicious keywords in a private `String[]` array. `countKeywordMatches(text)` traverses the array with a `for` loop and returns a count. `getMatchedKeywords(text)` uses an enhanced `for-each` loop to build a comma-separated list of matches.

---

## OOP Concepts Demonstrated

### Inheritance
```
WebsiteSource  (abstract)
├── TrustedSource    extends WebsiteSource
├── SuspiciousSource extends WebsiteSource
└── NeutralSource    extends WebsiteSource
```
Each subclass calls `super(url)` in its constructor to initialize the shared parent fields.

### Polymorphism
The variable `site` is declared as type `WebsiteSource` (the abstract parent), but holds a `TrustedSource`, `SuspiciousSource`, or `NeutralSource` at runtime:

```java
WebsiteSource site;              // declared as parent type

if (isTrustedDomain(lower)) {
    site = new TrustedSource(url, "Government");     // child object

} else if (isSuspiciousDomain(lower)) {
    site = new SuspiciousSource(url, "Flagged");     // different child

} else {
    site = new NeutralSource(url);                   // third child
}

site.calculateCredibility();  // Java picks the right version at runtime
```

The `ArrayList<WebsiteSource>` in `CredibilityEngine` stores all three subclass types together — that is polymorphism in data storage.

### Abstraction
`calculateCredibility()` is declared `abstract` in `WebsiteSource`. Callers never need to know which subclass they have — they just call `site.calculateCredibility()` and the correct logic runs automatically.

### Encapsulation
All fields in `WebsiteSource` are `private`. External classes can only access them through public `getters` and `setters` (`getUrl()`, `setCredibilityScore()`, `setContentWarnings()`, etc.). The `suspiciousKeywords` array in `KeywordScanner` is also `private`, accessed only through its public methods.

---

## Data Structures Used

| Structure | Where | Why |
|---|---|---|
| `String[]` array | `KeywordScanner.suspiciousKeywords` | Fixed-size keyword list; size known at compile time |
| `String[]` array | `WebpageAnalyzer.suspiciousPhrases` | Fixed-size phrase list for content scanning |
| `String[]` array | `Main.runAutomatedTests()` — testUrls, testLabels | Fixed set of 10 test cases |
| `ArrayList<WebsiteSource>` | `CredibilityEngine.analysisHistory` | Grows dynamically as user checks URLs |
| `ArrayList<String>` | `WebsiteSource.flags` | Unknown number of flags per site |
| `ArrayList<String>` | `WebsiteSource.contentWarnings` | Unknown number of content warnings |
| `ArrayList<String>` | `FileManager.readHistory()` return value | Unknown number of file lines |

---

## Scoring Algorithm

All URLs start at a **baseline score of 50** (neutral).

**URL-based adjustments (applied by subclass):**

| Rule | Points |
|---|---|
| `.gov` domain | +30 |
| `.edu` domain | +25 |
| `.org` domain | +10 |
| HTTPS protocol | +10 |
| `.xyz` domain | -20 |
| No HTTPS | -5 |
| Excessive URL symbols | -10 |
| Per suspicious keyword in URL | -5 each |

**Content-based adjustments (applied by WebpageAnalyzer):**

| Rule | Points |
|---|---|
| Per suspicious phrase in page HTML | -3 each |
| More than 5 exclamation marks | -5 |
| Excessive ALL-CAPS words (>5 words) | -10 |

**Rating thresholds:**

| Score | Rating |
|---|---|
| 80–100 | Highly Credible |
| 60–79 | Mostly Credible |
| 40–59 | Questionable |
| 0–39 | Suspicious |

---

## AP CSA Requirements Checklist

| Requirement | Where Demonstrated |
|---|---|
| At least one class hierarchy | `WebsiteSource` → `TrustedSource`, `SuspiciousSource`, `NeutralSource` |
| Abstract class | `WebsiteSource` with `abstract calculateCredibility()` |
| Method overriding | All three subclasses override `calculateCredibility()` |
| Polymorphism | `CredibilityEngine.analyze()` — parent-type variable, dynamic dispatch |
| Encapsulation | All `WebsiteSource` fields are `private` with public getters/setters |
| Array | `KeywordScanner.suspiciousKeywords[]`, `WebpageAnalyzer.suspiciousPhrases[]`, test arrays in `Main` |
| ArrayList | `CredibilityEngine.analysisHistory`, `WebsiteSource.flags`, `WebsiteSource.contentWarnings` |
| For loop | Everywhere — keyword scan, history traversal, stats, content analysis |
| While loop | Main menu loop in `Main.main()` |
| If/else conditionals | TLD checks, score thresholds, validation checks throughout |
| Exception handling | `FileManager`, `WebpageAnalyzer.fetchContent()`, `InputValidator.validateMenuChoice()` |
| File I/O | `FileManager.saveResult()`, `FileManager.readHistory()` |
| String methods | `toLowerCase()`, `contains()`, `startsWith()`, `split()`, `charAt()`, `trim()` |
| Constructor with `super()` | All three subclasses |
| `instanceof` operator | `CredibilityEngine.printStats()` — checks subclass type |
| Network I/O (bonus) | `WebpageAnalyzer.fetchContent()` — `java.net.URL`, `URLConnection` |

---

*TruthGuard — AP Computer Science A Final Project*
