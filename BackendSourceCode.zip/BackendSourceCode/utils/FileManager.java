import java.io.File;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

// ════════════════════════════════════════════════════════════════════════════
//  FileManager.java
//  TruthGuard — AP Computer Science A Final Project
// ════════════════════════════════════════════════════════════════════════════
/**
 * FileManager — Persistent Storage Handler
 *
 * Handles all reading and writing of history data to disk.
 * Uses only AP CSA-appropriate Java file I/O classes.
 *
 * ── AP CSA Concepts demonstrated ────────────────────────────────────────────
 *  ✦ File handling      : File, PrintWriter, FileWriter for writing;
 *                         Scanner for reading — same Scanner as keyboard input
 *  ✦ Exception handling : try/catch blocks around ALL file operations
 *  ✦ Methods            : saveResult(), readHistory(), printHistory(), etc.
 *  ✦ ArrayList          : readHistory() returns ArrayList<String>
 *  ✦ Loops              : while loop reads lines; for loop prints them
 *  ✦ Encapsulation      : filePath is private; accessed only via getFilePath()
 * ────────────────────────────────────────────────────────────────────────────
 *
 * Two output files managed:
 *   data/history.txt      — human-readable formatted text (for console display)
 *   data/history-api.json — machine-readable NDJSON (for the web frontend API)
 */
public class FileManager {

    // ── File path field (Encapsulation) ──────────────────────────────────────
    private String filePath; // path to the human-readable history .txt file

    // ── Constructor ──────────────────────────────────────────────────────────
    /**
     * Creates a FileManager targeting the given file path.
     *
     * @param filePath path to the .txt history file (e.g. "data/history.txt")
     */
    public FileManager(String filePath) {
        this.filePath = filePath;
    }

    // ── Save a result to the text history file ───────────────────────────────
    /**
     * Appends a WebsiteSource result to the human-readable history file.
     * Uses PrintWriter with append mode (FileWriter true = append, not overwrite).
     * Wrapped in try/catch for exception handling (AP CSA requirement).
     *
     * @param site the analyzed WebsiteSource to save
     */
    public void saveResult(WebsiteSource site) {
        // try/catch for exception handling (AP CSA requirement)
        try {
            // FileWriter in append mode so we don't overwrite old entries
            PrintWriter writer = new PrintWriter(new FileWriter(filePath, true));

            // Write a formatted entry to the file
            writer.println("----------------------------------------");
            writer.println("URL     : " + site.getUrl());
            writer.println("Type    : " + site.getClass().getSimpleName());
            writer.println("Score   : " + site.getCredibilityScore() + " / 100");
            writer.println("Rating  : " + site.classifyScore(site.getCredibilityScore()));
            writer.println("Flags   :");
            writer.print(site.getFlagsAsString());
            writer.println("----------------------------------------");

            writer.close(); // always close the writer to flush and release the file

            System.out.println("[FileManager] Result saved to: " + filePath);

        } catch (Exception e) {
            // Catch any IOException or other error and report without crashing
            System.out.println("[FileManager] Error saving result: " + e.getMessage());
        }
    }

    // ── Read history from file ───────────────────────────────────────────────
    /**
     * Reads all lines from the history file and returns them as an ArrayList.
     *
     * Demonstrates:
     *   ✦ Scanner for file reading (same class used for System.in keyboard input)
     *   ✦ ArrayList<String> to collect results dynamically
     *   ✦ while loop to read until end of file
     *   ✦ try/catch for missing or unreadable file
     *
     * @return ArrayList<String> where each element is one line from the file
     */
    public ArrayList<String> readHistory() {
        ArrayList<String> lines = new ArrayList<String>();

        try {
            File file = new File(filePath);

            // Conditional: check if file exists before reading
            if (!file.exists()) {
                System.out.println("[FileManager] No history file found at: " + filePath);
                return lines; // return empty list gracefully
            }

            Scanner fileScanner = new Scanner(file);

            // Loop: read each line until end of file (AP CSA loop)
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                lines.add(line); // add each line to the ArrayList
            }

            fileScanner.close(); // always close the scanner

        } catch (Exception e) {
            System.out.println("[FileManager] Error reading history: " + e.getMessage());
        }

        return lines;
    }

    // ── Print history to console ─────────────────────────────────────────────
    /**
     * Reads the history file and prints every line to the console.
     * Demonstrates method calling, loop, and ArrayList traversal.
     */
    public void printHistory() {
        ArrayList<String> lines = readHistory();

        if (lines.isEmpty()) {
            System.out.println("[FileManager] History is empty or file not found.");
            return;
        }

        System.out.println("\n=== Saved History from File: " + filePath + " ===");
        // For loop: loop through the ArrayList and print each line
        for (int i = 0; i < lines.size(); i++) {
            System.out.println(lines.get(i));
        }
    }

    // ── Clear history file ───────────────────────────────────────────────────
    /**
     * Clears the history file by overwriting it with an empty string.
     * Uses PrintWriter in non-append mode (default overwrites existing content).
     */
    public void clearHistory() {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(filePath, false));
            writer.print(""); // write empty string to erase file content
            writer.close();
            System.out.println("[FileManager] History file cleared.");
        } catch (Exception e) {
            System.out.println("[FileManager] Error clearing history: " + e.getMessage());
        }
    }

    // ── Save result as JSON line (NDJSON) ────────────────────────────────────
    /**
     * Appends a JSON-formatted result line to data/history-api.json.
     * This machine-readable file is consumed by the Node.js API server
     * to power the /api/history endpoint for the web frontend.
     *
     * Each line is a complete JSON object (newline-delimited JSON / NDJSON).
     * A timestamp field is appended using java.time.LocalDateTime.
     *
     * @param site the analyzed WebsiteSource to save as JSON
     */
    public void saveResultJson(WebsiteSource site) {
        String jsonFilePath = filePath.replace("history.txt", "history-api.json");
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(jsonFilePath, true));

            // Build a JSON object with a timestamp field added
            // We strip the closing } from toJson() and append the timestamp
            String baseJson = site.toJson();
            String withTimestamp = baseJson.substring(0, baseJson.length() - 1)
                    + ",\"timestamp\":\""
                    + java.time.LocalDateTime.now().toString()
                    + "\"}";

            writer.println(withTimestamp); // one JSON object per line (NDJSON)
            writer.close();

        } catch (Exception e) {
            System.err.println("[FileManager] Error saving JSON result: " + e.getMessage());
        }
    }

    // ── Get file path ────────────────────────────────────────────────────────
    /**
     * Returns the file path this FileManager was initialized with.
     *
     * @return the filePath string
     */
    public String getFilePath() {
        return filePath;
    }
}
