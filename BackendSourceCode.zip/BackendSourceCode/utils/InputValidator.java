// ════════════════════════════════════════════════════════════════════════════
//  InputValidator.java
//  TruthGuard — AP Computer Science A Final Project
// ════════════════════════════════════════════════════════════════════════════
/**
 * InputValidator — User Input Sanitization and Validation
 *
 * A utility class that prevents the program from crashing or producing
 * incorrect results when the user provides bad input (empty strings,
 * non-URLs, invalid menu choices, wrong protocols, etc.).
 *
 * ── AP CSA Concepts demonstrated ────────────────────────────────────────────
 *  ✦ Classes & Objects  : standalone utility class; instantiated in Main
 *  ✦ Methods            : each validation task is its own named method
 *  ✦ Parameters         : all methods take typed parameters
 *  ✦ Return values      : boolean, String, int — meaningful typed returns
 *  ✦ Conditionals       : null check, format check, range check
 *  ✦ Exception handling : try/catch wraps Integer.parseInt()
 *  ✦ String methods     : trim(), isEmpty(), startsWith(), contains(), replace()
 * ────────────────────────────────────────────────────────────────────────────
 */
public class InputValidator {

    // ── Check: is the input empty or null? ──────────────────────────────────
    /**
     * Returns true if the input is null, blank, or only whitespace.
     *
     * Demonstrates: null check conditional, String.trim(), isEmpty()
     *
     * @param input the user-provided string
     * @return true if input is null or blank
     */
    public boolean isEmpty(String input) {
        // Conditional: check for null first to avoid NullPointerException
        if (input == null) {
            return true;
        }
        // trim() removes leading/trailing spaces; isEmpty() checks length == 0
        return input.trim().isEmpty();
    }

    // ── Check: does it look like a valid URL? ────────────────────────────────
    /**
     * Returns true if the input looks like a plausible URL.
     * Checks for http/https protocol and presence of a dot in the domain.
     *
     * Demonstrates: String methods, nested conditionals, boolean return.
     *
     * @param input the user-provided string
     * @return true if the input appears to be a valid URL
     */
    public boolean isValidUrl(String input) {
        // First: can't be empty
        if (isEmpty(input)) {
            return false;
        }

        String trimmed = input.trim().toLowerCase();

        // Must start with http:// or https://
        boolean hasProtocol = trimmed.startsWith("http://") || trimmed.startsWith("https://");

        if (!hasProtocol) {
            return false;
        }

        // Must contain a dot after the protocol (e.g. http://x.com needs at least one dot)
        String withoutProtocol = trimmed.replace("https://", "").replace("http://", "");
        boolean hasDot = withoutProtocol.contains(".");

        if (!hasDot) {
            return false;
        }

        // Must have at least 3 characters after the protocol (e.g. "a.b")
        boolean longEnough = withoutProtocol.length() >= 3;

        return longEnough; // return combined result
    }

    // ── Validate and return a clean URL, or null on failure ─────────────────
    /**
     * Validates the input and returns a trimmed version if valid,
     * or null if the input is empty or not a valid URL.
     * Prints a descriptive error message for each failure case.
     *
     * Demonstrates: multiple conditionals, String return, console output.
     *
     * @param input the raw user input
     * @return the cleaned URL string, or null if invalid
     */
    public String validateAndClean(String input) {
        // Check 1: empty input
        if (isEmpty(input)) {
            System.out.println("[Validator] Error: Input cannot be empty.");
            return null;
        }

        String trimmed = input.trim();

        // Check 2: URL format
        if (!isValidUrl(trimmed)) {
            System.out.println("[Validator] Error: \"" + trimmed + "\" is not a valid URL.");
            System.out.println("            URLs must start with http:// or https:// and contain a domain.");
            return null;
        }

        // All checks passed — return the cleaned URL
        return trimmed;
    }

    // ── Validate a menu choice ───────────────────────────────────────────────
    /**
     * Validates that a menu selection is a number within the given range.
     * Wraps Integer.parseInt() in a try/catch to handle non-numeric input.
     *
     * Demonstrates:
     *   ✦ Exception handling: NumberFormatException caught gracefully
     *   ✦ Conditionals: range validation
     *   ✦ Return value: -1 signals "invalid input" to the caller
     *
     * @param input the user's menu choice as a string
     * @param min   the minimum valid option number
     * @param max   the maximum valid option number
     * @return the parsed integer if valid, or -1 if invalid
     */
    public int validateMenuChoice(String input, int min, int max) {
        // Exception handling: parseInt can throw NumberFormatException
        try {
            int choice = Integer.parseInt(input.trim());

            // Conditional: check range
            if (choice < min || choice > max) {
                System.out.println("[Validator] Please enter a number between " + min + " and " + max + ".");
                return -1;
            }

            return choice; // valid choice

        } catch (NumberFormatException e) {
            // Catch non-numeric input gracefully (AP CSA exception handling)
            System.out.println("[Validator] \"" + input.trim() + "\" is not a valid number. Please try again.");
            return -1;
        }
    }
}
