// ════════════════════════════════════════════════════════════════════════════
//  KeywordScanner.java
//  TruthGuard — AP Computer Science A Final Project
// ════════════════════════════════════════════════════════════════════════════
/**
 * KeywordScanner — URL and Text Keyword Matching Utility
 *
 * Scans a URL or text string for known misinformation-related keywords
 * and returns a count of how many were found. Used by SuspiciousSource
 * and NeutralSource during their credibility scoring.
 *
 * ── AP CSA Concepts demonstrated ────────────────────────────────────────────
 *  ✦ Arrays         : stores 15 suspicious keywords in a private String array
 *  ✦ Loops          : standard for loop AND enhanced for-each loop over array
 *  ✦ Methods        : countKeywordMatches(), getMatchedKeywords(), printAllKeywords()
 *  ✦ Return values  : int count and String listing of found keywords
 *  ✦ Encapsulation  : array is private; all access through public methods
 *  ✦ String methods : contains() for substring matching
 * ────────────────────────────────────────────────────────────────────────────
 */
public class KeywordScanner {

    // ── Array of suspicious keywords (AP CSA array requirement) ─────────────
    //
    //  WHY an array (not ArrayList)?
    //  → This list is fixed at compile time — it never changes at runtime.
    //  → Arrays are the correct choice for fixed-size data structures.
    //
    //  These keywords commonly appear in low-credibility or clickbait URLs.
    //
    private String[] suspiciousKeywords = {
        "fake",
        "hoax",
        "conspiracy",
        "clickbait",
        "shocking",
        "unbelievable",
        "truth-hidden",
        "secret",
        "exposed",
        "miracle",
        "banned",
        "censored",
        "deepstate",
        "mainstream-lie",
        "wakeup"
    };

    // ── Constructor ──────────────────────────────────────────────────────────
    /**
     * Default constructor. The keyword array is initialized at declaration.
     */
    public KeywordScanner() {
        // nothing extra needed — array initialized at declaration
    }

    // ── Core method: count keyword matches ───────────────────────────────────
    /**
     * Loops through the suspiciousKeywords array and counts how many appear
     * in the given text (URL or content string).
     *
     * Demonstrates:
     *   ✦ Standard for loop (index-based array traversal — AP CSA array loop)
     *   ✦ String.contains() for substring matching
     *   ✦ Accumulator counter pattern
     *
     * @param text the URL or text to scan (should already be lowercased)
     * @return the number of suspicious keyword matches found
     */
    public int countKeywordMatches(String text) {
        int matchCount = 0; // counter — reset for each call

        // For loop iterating over the keyword array (AP CSA array loop)
        for (int i = 0; i < suspiciousKeywords.length; i++) {
            // Check if this keyword appears anywhere in the text
            if (text.contains(suspiciousKeywords[i])) {
                matchCount++; // increment counter on match
            }
        }

        return matchCount; // return total matches found
    }

    // ── Find and list matched keywords ──────────────────────────────────────
    /**
     * Returns a comma-separated list of which keywords were found.
     * Used for detailed reporting in the console output.
     *
     * Demonstrates:
     *   ✦ Enhanced for-each loop over String[] (alternative to index-based loop)
     *   ✦ StringBuilder for efficient string building
     *   ✦ Conditional: return "none" if no matches found
     *
     * @param text the URL or text to scan (should already be lowercased)
     * @return String listing matched keywords, or "none" if no matches
     */
    public String getMatchedKeywords(String text) {
        StringBuilder found = new StringBuilder();
        int count = 0;

        // Enhanced for-each loop over array (demonstrates AP CSA variety)
        for (String keyword : suspiciousKeywords) {
            if (text.contains(keyword)) {
                if (count > 0) {
                    found.append(", "); // add separator between matches
                }
                found.append(keyword);
                count++;
            }
        }

        // Conditional: return "none" if no matches were found
        if (count == 0) {
            return "none";
        }
        return found.toString();
    }

    // ── Get the full keyword list ────────────────────────────────────────────
    /**
     * Returns the array of suspicious keywords.
     * Useful for displaying the full keyword list in the console menu.
     *
     * @return the suspiciousKeywords String[] array
     */
    public String[] getKeywords() {
        return suspiciousKeywords;
    }

    // ── Print all keywords to console ────────────────────────────────────────
    /**
     * Prints every keyword in the array, numbered.
     * Demonstrates: loop, array access by index, console output.
     */
    public void printAllKeywords() {
        System.out.println("=== Suspicious Keywords List ===");
        // Standard for loop with index (AP CSA loop)
        for (int i = 0; i < suspiciousKeywords.length; i++) {
            System.out.println("  " + (i + 1) + ". " + suspiciousKeywords[i]);
        }
        System.out.println("================================");
    }
}
