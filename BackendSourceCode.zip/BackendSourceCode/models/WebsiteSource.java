import java.util.ArrayList;

// ════════════════════════════════════════════════════════════════════════════
//  WebsiteSource.java
//  TruthGuard — AP Computer Science A Final Project
// ════════════════════════════════════════════════════════════════════════════
/**
 * WebsiteSource — ABSTRACT BASE CLASS
 *
 * The foundation of TruthGuard's OOP structure. This abstract class defines
 * the shared data and behavior for ALL website types in the system.
 *
 * Subclasses (TrustedSource, SuspiciousSource, NeutralSource) extend this
 * class and each provide their own version of calculateCredibility().
 *
 * ── AP CSA Concepts demonstrated ────────────────────────────────────────────
 *  ✦ Abstraction    : abstract class cannot be instantiated directly;
 *                     calculateCredibility() is abstract (must be overridden)
 *  ✦ Encapsulation  : all fields are private; access via public getters/setters
 *  ✦ Inheritance    : TrustedSource, SuspiciousSource, NeutralSource extend this
 *  ✦ Polymorphism   : calculateCredibility() overridden in each subclass
 *  ✦ ArrayList      : flags and contentWarnings use ArrayList<String>
 * ────────────────────────────────────────────────────────────────────────────
 */
public abstract class WebsiteSource {

    // ── Encapsulated fields — all private (Encapsulation) ────────────────────
    // Private fields cannot be changed from outside without going through setters.
    // This protects the data from accidental modification.

    private String url;                        // the URL being analyzed
    private int credibilityScore;              // current score (0–100)
    private ArrayList<String> flags;           // URL-based scoring adjustments

    // Content analysis fields (populated by WebpageAnalyzer)
    private ArrayList<String> contentWarnings; // suspicious phrases found in page
    private boolean contentAnalyzed;           // true if page was successfully fetched

    // ── Constructor ──────────────────────────────────────────────────────────
    /**
     * Initializes a WebsiteSource with a URL.
     * Score starts at 50 — the neutral baseline for all sites.
     * Flags and contentWarnings start as empty ArrayLists.
     *
     * @param url  the URL string to evaluate
     */
    public WebsiteSource(String url) {
        this.url              = url;
        this.credibilityScore = 50;                     // neutral starting point
        this.flags            = new ArrayList<String>(); // URL scoring flags
        this.contentWarnings  = new ArrayList<String>(); // content analysis findings
        this.contentAnalyzed  = false;                  // not yet analyzed
    }

    // ── Abstract method: must be implemented by every subclass ───────────────
    /**
     * Calculates the credibility score using subclass-specific rules.
     *
     * WHY abstract?
     *   TrustedSource, SuspiciousSource, and NeutralSource all score URLs
     *   differently. By declaring this abstract, we FORCE each subclass to
     *   provide its own implementation. The caller just says site.calculateCredibility()
     *   and Java picks the right version at runtime — POLYMORPHISM.
     *
     * @return  the final credibility score after applying all scoring rules
     */
    public abstract int calculateCredibility();

    // ── Shared helper: classify numeric score → text label ──────────────────
    /**
     * Converts a numeric score (0–100) into a human-readable rating label.
     * Uses a chain of if-else conditionals (AP CSA conditional requirement).
     *
     * @param score  the numeric credibility score
     * @return       a String label: "Highly Credible", "Mostly Credible",
     *               "Questionable", or "Suspicious"
     */
    public String classifyScore(int score) {
        if (score >= 80) {
            return "Highly Credible";
        } else if (score >= 60) {
            return "Mostly Credible";
        } else if (score >= 40) {
            return "Questionable";
        } else {
            return "Suspicious";
        }
    }

    // ── Flag management (URL-based scoring reasons) ──────────────────────────

    /**
     * Adds a flag explaining why the score was adjusted by a URL-based rule.
     * Example: ".gov domain detected (+30)"
     *
     * @param flag  a short description of the scoring rule that triggered
     */
    public void addFlag(String flag) {
        flags.add(flag);
    }

    /**
     * Returns all URL-based scoring flags as a formatted, numbered string.
     *
     * @return  newline-separated list of flags, or "(no flags)" if empty
     */
    public String getFlagsAsString() {
        if (flags.isEmpty()) {
            return "  (no flags)";
        }
        StringBuilder sb = new StringBuilder();
        // For loop: traverse the flags ArrayList (AP CSA ArrayList loop)
        for (int i = 0; i < flags.size(); i++) {
            sb.append("  [!] ").append(flags.get(i)).append("\n");
        }
        return sb.toString();
    }

    // ── Getters and Setters ──────────────────────────────────────────────────
    // Public getters/setters provide CONTROLLED access to private fields.
    // This is the core of Encapsulation in Java.

    /** @return the URL string */
    public String getUrl() { return url; }

    /** @param url  new URL to set */
    public void setUrl(String url) { this.url = url; }

    /** @return the current credibility score (0–100) */
    public int getCredibilityScore() { return credibilityScore; }

    /**
     * Sets the credibility score.
     * Should be called inside calculateCredibility() after all adjustments.
     *
     * @param score  the new score value
     */
    public void setCredibilityScore(int score) { this.credibilityScore = score; }

    /** @return the ArrayList of URL-based scoring flags */
    public ArrayList<String> getFlags() { return flags; }

    /** @return the ArrayList of suspicious phrases found in page content */
    public ArrayList<String> getContentWarnings() { return contentWarnings; }

    /**
     * Sets the content warnings list (called by WebpageAnalyzer).
     *
     * @param warnings  the ArrayList of matched suspicious phrases
     */
    public void setContentWarnings(ArrayList<String> warnings) {
        this.contentWarnings = warnings;
    }

    /** @return true if WebpageAnalyzer successfully fetched the page */
    public boolean isContentAnalyzed() { return contentAnalyzed; }

    /**
     * Marks whether the page content was successfully fetched and analyzed.
     *
     * @param analyzed  true if the page was fetched; false if it failed
     */
    public void setContentAnalyzed(boolean analyzed) {
        this.contentAnalyzed = analyzed;
    }

    // ── JSON serialization ───────────────────────────────────────────────────
    /**
     * Serializes this WebsiteSource to a JSON string.
     * Written manually without any JSON library (AP CSA appropriate).
     * Used by Main's --check CLI mode so the Express web server can parse results.
     *
     * Fields included:
     *   url, type, score, rating, flags[], contentAnalyzed,
     *   contentWarnings[], contentWarningCount
     *
     * @return  a complete JSON string representing this analysis result
     */
    public String toJson() {
        int score = getCredibilityScore();
        StringBuilder json = new StringBuilder();
        json.append("{");

        // Core fields
        json.append("\"url\":\"").append(escapeJson(url)).append("\",");
        json.append("\"type\":\"").append(getClass().getSimpleName()).append("\",");
        json.append("\"score\":").append(score).append(",");
        json.append("\"rating\":\"").append(classifyScore(score)).append("\",");

        // URL-based scoring flags array
        json.append("\"flags\":[");
        for (int i = 0; i < flags.size(); i++) {
            if (i > 0) json.append(",");
            json.append("\"").append(escapeJson(flags.get(i))).append("\"");
        }
        json.append("],");

        // Content analysis fields
        json.append("\"contentAnalyzed\":").append(contentAnalyzed).append(",");
        json.append("\"contentWarningCount\":").append(contentWarnings.size()).append(",");
        json.append("\"contentWarnings\":[");
        // Loop through content warnings ArrayList
        for (int i = 0; i < contentWarnings.size(); i++) {
            if (i > 0) json.append(",");
            json.append("\"").append(escapeJson(contentWarnings.get(i))).append("\"");
        }
        json.append("]");

        json.append("}");
        return json.toString();
    }

    /**
     * Escapes special characters that would break JSON string syntax.
     *
     * @param s  the raw string to escape
     * @return   the safely escaped string
     */
    private String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    // ── toString ─────────────────────────────────────────────────────────────
    /**
     * Returns a formatted multi-line summary of this result for console display.
     * Includes URL-based flags and content analysis findings if available.
     *
     * @return  a human-readable string summary
     */
    @Override
    public String toString() {
        int score = getCredibilityScore();
        StringBuilder sb = new StringBuilder();
        sb.append("URL     : ").append(url).append("\n");
        sb.append("Type    : ").append(getClass().getSimpleName()).append("\n");
        sb.append("Score   : ").append(score).append(" / 100\n");
        sb.append("Rating  : ").append(classifyScore(score)).append("\n");
        sb.append("Flags   :\n").append(getFlagsAsString());

        // Conditional: show content analysis section if the page was fetched
        if (contentAnalyzed) {
            sb.append("Content : Page scanned — ");
            if (contentWarnings.isEmpty()) {
                sb.append("no suspicious phrases found.\n");
            } else {
                sb.append(contentWarnings.size()).append(" suspicious phrase(s) found:\n");
                // Loop through content warnings ArrayList
                for (int i = 0; i < contentWarnings.size(); i++) {
                    sb.append("  [!] \"").append(contentWarnings.get(i)).append("\"\n");
                }
            }
        } else {
            sb.append("Content : Page not fetched (offline, blocked, or timed out)\n");
        }

        return sb.toString();
    }
}
