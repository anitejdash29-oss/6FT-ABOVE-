/**
 * NeutralSource — SUBCLASS of WebsiteSource
 *
 * Represents the most common category: websites that are neither clearly
 * trusted nor clearly suspicious. Both positive and negative rules are applied,
 * and the score can go either direction from the 50-point baseline.
 *
 * ── AP CSA Concepts demonstrated ────────────────────────────────────────────
 *  ✦ Inheritance    : extends WebsiteSource
 *  ✦ Polymorphism   : overrides calculateCredibility() with balanced logic
 *  ✦ Constructors   : uses super() to delegate initialization to parent
 *  ✦ Conditionals   : applies both bonus and penalty rules
 *  ✦ Loops          : uses KeywordScanner which traverses a String array
 * ────────────────────────────────────────────────────────────────────────────
 *
 * Scoring rules applied in calculateCredibility():
 *   +10 for .org domain
 *   +10 for HTTPS protocol
 *   -20 for .xyz domain
 *   -5  per suspicious keyword in URL (via KeywordScanner)
 *   Score is clamped between 0 and 100.
 */
public class NeutralSource extends WebsiteSource {

    // ── Constructor ──────────────────────────────────────────────────────────
    /**
     * Creates a NeutralSource.
     * No extra fields needed — neutral sources have no pre-classification.
     *
     * @param url the URL to evaluate
     */
    public NeutralSource(String url) {
        super(url); // delegate to parent constructor
    }

    // ── Overridden abstract method (Polymorphism) ────────────────────────────
    /**
     * Calculates credibility using a balanced ruleset — applies both bonuses
     * and penalties depending on what the URL contains.
     *
     * This method OVERRIDES calculateCredibility() from WebsiteSource.
     * A NeutralSource starts at 50 and can go up or down depending on
     * whether positive signals (https, .org) outweigh negative ones
     * (.xyz, suspicious keywords).
     *
     * Demonstrates: method overriding, conditionals, moderate scoring logic.
     *
     * @return the final credibility score
     */
    @Override
    public int calculateCredibility() {
        String url = getUrl().toLowerCase();
        int score = getCredibilityScore(); // start at baseline 50

        // ── Positive rules ────────────────────────────────────────────────

        if (url.contains(".org")) {
            score += 10;
            addFlag(".org domain (+10)");
        }

        if (url.startsWith("https")) {
            score += 10;
            addFlag("HTTPS protocol (+10)");
        }

        // ── Negative rules ────────────────────────────────────────────────

        if (url.contains(".xyz")) {
            score -= 20;
            addFlag(".xyz domain (-20)");
        }

        // Check for suspicious keywords via KeywordScanner
        // KeywordScanner internally uses a String[] array and a for loop
        KeywordScanner scanner = new KeywordScanner();
        int hits = scanner.countKeywordMatches(url);

        // Loop: subtract 5 for each suspicious keyword found
        for (int i = 0; i < hits; i++) {
            score -= 5;
        }

        if (hits > 0) {
            addFlag(hits + " suspicious keyword(s) (-" + (hits * 5) + ")");
        }

        // ── Clamp score between 0 and 100 ────────────────────────────────
        if (score > 100) score = 100;
        if (score < 0)   score = 0;

        setCredibilityScore(score);
        return score;
    }
}
