/**
 * TrustedSource — SUBCLASS of WebsiteSource
 *
 * Represents websites that belong to verified, authoritative domains
 * such as government (.gov) and academic (.edu) institutions.
 *
 * ── AP CSA Concepts demonstrated ────────────────────────────────────────────
 *  ✦ Inheritance    : extends WebsiteSource, inherits all fields and methods
 *  ✦ Polymorphism   : overrides calculateCredibility() with trusted-source logic
 *  ✦ Encapsulation  : adds its own private field (verifiedBy)
 *  ✦ Constructors   : calls super() to initialize parent fields
 *  ✦ Conditionals   : if-else chain applies domain-based scoring bonuses
 * ────────────────────────────────────────────────────────────────────────────
 *
 * Scoring rules applied in calculateCredibility():
 *   +30 for .gov domain
 *   +25 for .edu domain
 *   +10 for .org domain
 *   +10 for HTTPS protocol
 *   Score is clamped at 100 maximum.
 */
public class TrustedSource extends WebsiteSource {

    // Additional field specific to TrustedSource
    // (Encapsulation: private, with a public getter below)
    private String verifiedBy; // e.g. "Government", "Academic Institution"

    // ── Constructor ──────────────────────────────────────────────────────────
    /**
     * Creates a TrustedSource.
     * Calls super() to initialize url and baseline score via parent constructor.
     *
     * @param url        the URL to evaluate
     * @param verifiedBy who verified this source (e.g. "Government")
     */
    public TrustedSource(String url, String verifiedBy) {
        super(url); // call parent constructor — AP CSA inheritance requirement
        this.verifiedBy = verifiedBy;
    }

    // ── Overridden abstract method (Polymorphism) ────────────────────────────
    /**
     * Calculates credibility score with a trusted-source lens.
     * Starts from parent's baseline (50) and applies positive domain bonuses.
     *
     * This method OVERRIDES the abstract calculateCredibility() in WebsiteSource.
     * When CredibilityEngine calls site.calculateCredibility() on a TrustedSource
     * object, THIS version runs — not the parent's (which has none, as it's abstract).
     *
     * Demonstrates: method overriding (polymorphism), conditionals.
     *
     * @return the final credibility score
     */
    @Override
    public int calculateCredibility() {
        String url = getUrl().toLowerCase(); // normalize to lowercase for comparison
        int score = getCredibilityScore();   // start at baseline 50

        // ── Domain-based scoring rules (conditionals) ─────────────────────
        if (url.contains(".gov")) {
            score += 30;
            addFlag(".gov domain detected (+30)");
        }

        if (url.contains(".edu")) {
            score += 25;
            addFlag(".edu domain detected (+25)");
        }

        if (url.contains(".org")) {
            score += 10;
            addFlag(".org domain detected (+10)");
        }

        // ── Protocol check ────────────────────────────────────────────────
        if (url.startsWith("https")) {
            score += 10;
            addFlag("HTTPS secure protocol (+10)");
        }

        // ── Cap score at 100 ─────────────────────────────────────────────
        if (score > 100) {
            score = 100;
        }

        setCredibilityScore(score);
        return score;
    }

    // ── Getter ───────────────────────────────────────────────────────────────
    /**
     * Returns the name of the authority that verified this source.
     *
     * @return the verifiedBy string (e.g. "Government")
     */
    public String getVerifiedBy() {
        return verifiedBy;
    }

    /**
     * Extends parent toString() with verified-by information.
     *
     * @return formatted string including parent fields + verifiedBy
     */
    @Override
    public String toString() {
        return super.toString() + "Verified: " + verifiedBy + "\n";
    }
}
