/**
 * SuspiciousSource — SUBCLASS of WebsiteSource
 *
 * Represents websites with characteristics associated with low credibility:
 * suspicious TLDs (.xyz, .tk, .ml, .cf), missing HTTPS, excessive URL symbols,
 * or URLs containing known misinformation keywords.
 *
 * ── AP CSA Concepts demonstrated ────────────────────────────────────────────
 *  ✦ Inheritance    : extends WebsiteSource
 *  ✦ Polymorphism   : overrides calculateCredibility() with penalty-heavy logic
 *  ✦ Encapsulation  : adds its own private field (suspicionReason)
 *  ✦ Arrays         : uses KeywordScanner (which holds a String array internally)
 *  ✦ Loops          : iterates over URL characters to count numbers and symbols;
 *                     loops to apply keyword penalty per match
 *  ✦ Conditionals   : checks protocol, TLD, symbol count, and keyword hits
 * ────────────────────────────────────────────────────────────────────────────
 *
 * Scoring rules applied in calculateCredibility():
 *   -20 for .xyz domain
 *   -5  for missing HTTPS
 *   -10 if URL contains excessive numbers/symbols (>6)
 *   -5  per suspicious keyword found in the URL (via KeywordScanner)
 *   Score is clamped at 0 minimum.
 */
public class SuspiciousSource extends WebsiteSource {

    // Additional field specific to SuspiciousSource
    // (Encapsulation: private, with a public getter below)
    private String suspicionReason;

    // ── Constructor ──────────────────────────────────────────────────────────
    /**
     * Creates a SuspiciousSource.
     *
     * @param url             the URL to evaluate
     * @param suspicionReason a description of why this source is flagged
     */
    public SuspiciousSource(String url, String suspicionReason) {
        super(url); // call parent constructor
        this.suspicionReason = suspicionReason;
    }

    // ── Overridden abstract method (Polymorphism) ────────────────────────────
    /**
     * Calculates credibility score applying penalties for suspicious traits.
     * Also uses KeywordScanner to check for misinformation-related keywords.
     *
     * This method OVERRIDES calculateCredibility() from WebsiteSource.
     * When CredibilityEngine calls site.calculateCredibility() on a
     * SuspiciousSource, THIS version runs automatically — dynamic dispatch.
     *
     * @return the final credibility score
     */
    @Override
    public int calculateCredibility() {
        String url = getUrl().toLowerCase();
        int score = getCredibilityScore(); // start at baseline 50

        // ── Penalty: suspicious TLD ───────────────────────────────────────
        if (url.contains(".xyz")) {
            score -= 20;
            addFlag(".xyz domain detected (-20)");
        }

        // ── Penalty: no HTTPS ─────────────────────────────────────────────
        if (!url.startsWith("https")) {
            score -= 5;
            addFlag("No HTTPS protocol (-5)");
        }

        // ── Penalty: excessive numbers and symbols in URL ─────────────────
        // Loop through each character in the URL (AP CSA loop requirement)
        int specialCount = 0;
        for (int i = 0; i < url.length(); i++) {
            char c = url.charAt(i);
            // Count digits and special characters (excluding standard URL chars)
            if (Character.isDigit(c) || (c != '.' && c != '/' && c != '-'
                    && c != '_' && c != ':' && !Character.isLetter(c))) {
                specialCount++;
            }
        }

        // If more than 6 numbers/symbols detected, apply penalty
        if (specialCount > 6) {
            score -= 10;
            addFlag("Too many numbers/symbols in URL (-10)");
        }

        // ── Keyword scanning via KeywordScanner ───────────────────────────
        KeywordScanner scanner = new KeywordScanner();
        int keywordHits = scanner.countKeywordMatches(url);

        // Loop: apply -5 penalty for each suspicious keyword found
        for (int i = 0; i < keywordHits; i++) {
            score -= 5;
        }

        if (keywordHits > 0) {
            addFlag(keywordHits + " suspicious keyword(s) detected (-" + (keywordHits * 5) + ")");
        }

        // ── Floor score at 0 ─────────────────────────────────────────────
        if (score < 0) {
            score = 0;
        }

        setCredibilityScore(score);
        return score;
    }

    // ── Getter ───────────────────────────────────────────────────────────────
    /**
     * Returns the reason this source was classified as suspicious.
     *
     * @return the suspicionReason string
     */
    public String getSuspicionReason() {
        return suspicionReason;
    }

    /**
     * Extends parent toString() with suspension reason.
     *
     * @return formatted string including parent fields + suspicionReason
     */
    @Override
    public String toString() {
        return super.toString() + "Suspicion Reason: " + suspicionReason + "\n";
    }
}
