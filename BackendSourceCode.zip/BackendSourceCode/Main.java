import java.util.ArrayList;
import java.util.Scanner;

// ════════════════════════════════════════════════════════════════════════════
//  Main.java
//  TruthGuard — AP Computer Science A Final Project
// ════════════════════════════════════════════════════════════════════════════
/**
 * Main — Entry Point and Interactive Menu System
 *
 * This class is the "hub" of TruthGuard. It connects all other classes,
 * manages the interactive console menu, runs automated tests, and provides
 * the JSON CLI mode used by the Express web API bridge.
 *
 * ── AP CSA Concepts demonstrated here ──────────────────────────────────────
 *  ✦ Classes & Objects   : creates instances of all major classes
 *  ✦ Polymorphism        : ArrayList<WebsiteSource> holds mixed subclass types
 *  ✦ Inheritance         : explicit demo (Option 5) shows extends chain
 *  ✦ Abstraction         : all analysis logic delegated to CredibilityEngine
 *  ✦ Arrays              : String[] arrays used for test URLs and labels
 *  ✦ ArrayLists          : used for polymorphism demo and search/filter results
 *  ✦ Loops               : while (menu), for (tests, demo, results)
 *  ✦ Conditionals        : menu routing, input validation branches
 *  ✦ Methods             : every action is its own well-named method
 *  ✦ Exception handling  : handled in InputValidator and FileManager
 *  ✦ File handling       : FileManager reads/writes history files
 * ────────────────────────────────────────────────────────────────────────────
 *
 * TWO MODES OF OPERATION:
 *
 *   1. INTERACTIVE CONSOLE MODE:   java -cp out Main
 *      Shows a 11-option menu. User types a number to pick an action.
 *      Menu stays open in a while loop until the user chooses Exit (11).
 *
 *   2. JSON CLI MODE:              java -cp out Main --check <url>
 *      Used by the Node.js / Express web API server.
 *      Analyzes the given URL, prints ONE clean JSON object to stdout, exits.
 *      All other output (FileManager prints, etc.) is redirected to stderr
 *      so it doesn't corrupt the JSON that Express reads.
 */
public class Main {

    // ── Shared program-wide instances ─────────────────────────────────────────
    // Created once; passed around or called from each menu method.
    // These are static so all static methods can access them without passing args.
    static CredibilityEngine engine     = new CredibilityEngine();
    static FileManager       fileManager = new FileManager("data/history.txt");
    static InputValidator    validator   = new InputValidator();
    static Scanner           input       = new Scanner(System.in);

    // ── Entry point ──────────────────────────────────────────────────────────
    /**
     * Program starts here.
     *
     * Two modes:
     *   1. JSON CLI mode: java Main --check <url>
     *      → Used by the Express web API server. Prints one JSON object, exits.
     *   2. Interactive mode: java Main
     *      → Shows the interactive console menu.
     *
     * @param args command-line arguments (optional: --check <url>)
     */
    public static void main(String[] args) {

        // ── JSON CLI mode: used by the Node.js Express API bridge ─────────
        // The Express server calls: java -cp out Main --check https://...
        // Java prints one JSON result to stdout, then exits.
        if (args.length >= 1 && args[0].equals("--check")) {
            if (args.length < 2 || args[1].trim().isEmpty()) {
                System.out.println("{\"error\":\"No URL provided\"}");
                return;
            }
            runJsonCheck(args[1].trim());
            return; // do not fall into the interactive menu
        }

        // ── Interactive console mode ───────────────────────────────────────
        printBanner();

        boolean running = true; // loop control variable

        // Main program loop — AP CSA while loop
        // Keeps the menu active until the user chooses Exit (option 11)
        while (running) {
            printMenu();

            String choice = input.nextLine();

            // validateMenuChoice catches non-numeric input and out-of-range values
            int option = validator.validateMenuChoice(choice, 1, 11);

            // ── switch-case: route each menu option to its handler method ──
            //
            //  WHY switch (not if-else)?
            //  → When branching on a single integer value with many cases,
            //    switch-case is cleaner and more readable than a long if-else
            //    chain. Each case maps directly to one menu action.
            //  → break; prevents fall-through to the next case.
            //  → default: handles any unexpected value gracefully.
            //
            switch (option) {
                case 1:  runCheckUrl();                                             break;
                case 2:  engine.printHistory();                                     break;
                case 3:  fileManager.printHistory();                                break;
                case 4:  runAutomatedTests();                                       break;
                case 5:  runPolymorphismDemo();                                     break;
                case 6:  new KeywordScanner().printAllKeywords();                   break;
                case 7:  engine.printStats();                                       break;
                case 8:  runSearchHistory();                                        break;
                case 9:  runFilterHistory();                                        break;
                case 10: runExportHistory();                                        break;
                case 11:
                    System.out.println("\nThank you for using TruthGuard. Stay informed!");
                    running = false; // exit the while loop
                    break;
                default:
                    System.out.println("  Invalid option. Please choose 1–11.");
            }
        }

        input.close(); // close Scanner when done
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MENU OPTION 1 — Check a URL
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Prompts the user for a URL, validates it, runs the credibility engine,
     * prints the result, and saves it to the history files.
     *
     * Demonstrates:
     *   ✦ Input validation (InputValidator)
     *   ✦ Polymorphism: analyze() returns a WebsiteSource subclass
     *   ✦ toString(): overridden in each subclass for formatted output
     *   ✦ File handling: result saved via FileManager
     */
    static void runCheckUrl() {
        System.out.println("\n─── Check a Website ─────────────────────────");
        System.out.println("Enter a URL to check (e.g. https://cdc.gov):");
        System.out.print("  > ");
        String raw = input.nextLine();

        // Validate and clean the input via InputValidator
        String url = validator.validateAndClean(raw);

        // Conditional: only proceed if validation passed (null means rejected)
        if (url == null) {
            System.out.println("  Returning to menu.\n");
            return;
        }

        System.out.println("\n  Analyzing: " + url + " ...\n");

        // analyze() uses polymorphism internally — returns correct subclass
        WebsiteSource result = engine.analyze(url);

        // Print result — toString() call is polymorphic
        System.out.println("  ── RESULT ───────────────────────────────────");
        System.out.println(result.toString());

        // Save to history files via FileManager
        fileManager.saveResult(result);     // human-readable .txt
        fileManager.saveResultJson(result); // machine-readable .json

        System.out.println("  ─────────────────────────────────────────────\n");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MENU OPTION 4 — Automated Test Suite
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Runs 10 pre-defined test cases automatically and prints results.
     *
     * Test cases include: trusted domains, suspicious domains, neutral sites,
     * and edge cases (empty input, wrong protocol, no domain, very long URLs).
     *
     * Demonstrates:
     *   ✦ Array: String[] arrays hold test URLs and labels
     *   ✦ For loop: traverses both arrays at the same index
     *   ✦ Conditionals: different handling for valid vs. invalid input
     *   ✦ Methods: analyze() called on each valid URL
     */
    static void runAutomatedTests() {
        System.out.println("\n╔══════════════════════════════════════════╗");
        System.out.println("║    TruthGuard — Automated Test Suite     ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        // ── 2D Array: test cases (AP CSA 2D array requirement) ──────────
        //
        //  WHY a 2D array (not two separate 1D arrays)?
        //  → Each test case has TWO related pieces of data: the URL and the
        //    expected label. A 2D array groups this data together in one
        //    structure — each ROW is one test case, each COLUMN is one field.
        //
        //  Layout:
        //    testCases[i][0] = the URL to test
        //    testCases[i][1] = the expected result description
        //
        //  Accessing: testCases[row][col] — standard 2D array syntax.
        //
        String[][] testCases = {
            // { URL to test,                                    Expected result label }
            { "https://www.cdc.gov/flu",                       "TC-01: Valid .gov URL (expected: Highly Credible)"      },
            { "https://mit.edu/research/ai",                   "TC-02: Valid .edu URL (expected: Highly Credible)"      },
            { "https://wikipedia.org/wiki/Climate_change",     "TC-03: Neutral .org URL (expected: Mostly Credible)"    },
            { "http://fake-news-exposed.xyz/shocking-truth",   "TC-04: Suspicious .xyz + keywords (expected: Suspicious)"},
            { "https://conspiracy-secret-hoax.xyz/hidden",     "TC-05: Multiple keyword hits (expected: Suspicious)"    },
            { "https://www.bbc.com/news",                      "TC-06: Reputable news site (expected: Mostly Credible)" },
            { "",                                               "TC-07: EDGE — Empty input (expected: rejected)"        },
            { "not-a-url-at-all",                               "TC-08: EDGE — Not a URL (expected: rejected)"          },
            { "ftp://weirdprotocol.com",                        "TC-09: EDGE — Wrong protocol (expected: rejected)"     },
            { "https://12345678901234567890.xyz/a1b2c3d4",      "TC-10: EDGE — Numbers + suspicious TLD (Suspicious)"   }
        };

        // For loop: process each test case by row index (AP CSA loop)
        for (int i = 0; i < testCases.length; i++) {
            String testUrl   = testCases[i][0]; // column 0 = URL to analyze
            String testLabel = testCases[i][1]; // column 1 = expected result label

            System.out.println("  ─────────────────────────────────────────");
            System.out.println("  " + testLabel);
            System.out.println("  Input : \"" + testUrl + "\"");

            // Validate first — invalid URLs print an error and skip analysis
            String cleaned = validator.validateAndClean(testUrl);

            if (cleaned == null) {
                // Conditional: validator rejected this input
                System.out.println("  Result: Rejected by InputValidator (expected)");
            } else {
                // Valid URL: analyze and print the result
                WebsiteSource site = engine.analyze(cleaned);
                int score = site.getCredibilityScore();
                System.out.println("  Type  : " + site.getClass().getSimpleName());
                System.out.println("  Score : " + score + " / 100  →  "
                        + site.classifyScore(score));
                System.out.println("  Flags :\n" + site.getFlagsAsString());

                // Save to history files for persistence
                fileManager.saveResult(site);
            }
        }

        System.out.println("  ─────────────────────────────────────────");
        System.out.println("  All " + testCases.length + " tests complete.");
        System.out.println("  Results saved to: " + fileManager.getFilePath());
        System.out.println("╚══════════════════════════════════════════╝\n");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MENU OPTION 5 — Polymorphism Demonstration
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Explicitly demonstrates runtime polymorphism for the AP CSA rubric.
     *
     * Shows:
     *   ✦ Parent-type variable (WebsiteSource) holding a child-type object
     *   ✦ ArrayList<WebsiteSource> storing mixed subclass instances
     *   ✦ Dynamic dispatch: Java picks the correct calculateCredibility()
     *     at runtime based on the actual subclass of each object
     */
    static void runPolymorphismDemo() {
        System.out.println("\n╔══════════════════════════════════════════╗");
        System.out.println("║       Polymorphism Demonstration         ║");
        System.out.println("╚══════════════════════════════════════════╝");
        System.out.println("  All five objects are stored in one ArrayList<WebsiteSource>.");
        System.out.println("  Each calls calculateCredibility() — but a different version.\n");

        // ── Polymorphism: parent reference = child object ──────────────
        //  The variable type is WebsiteSource (abstract parent),
        //  but the actual object created is a concrete subclass.
        WebsiteSource site1 = new TrustedSource(
                "https://nasa.gov/mars", "Government");
        WebsiteSource site2 = new SuspiciousSource(
                "http://hoax-exposed.xyz", "Known misinformation domain");
        WebsiteSource site3 = new NeutralSource(
                "https://wikipedia.org/wiki/Vaccine");
        WebsiteSource site4 = new TrustedSource(
                "https://harvard.edu/study/ai", "Academic Institution");
        WebsiteSource site5 = new SuspiciousSource(
                "http://conspiracy-secret.xyz/truth", "Keyword pattern match");

        // ── ArrayList storing mixed subclass types ─────────────────────
        //  ArrayList<WebsiteSource> holds TrustedSource AND SuspiciousSource
        //  AND NeutralSource — all at once. This is polymorphism in storage.
        ArrayList<WebsiteSource> demoList = new ArrayList<WebsiteSource>();
        demoList.add(site1);
        demoList.add(site2);
        demoList.add(site3);
        demoList.add(site4);
        demoList.add(site5);

        // For loop: call calculateCredibility() on every element
        // Java resolves WHICH version to call at runtime (dynamic dispatch)
        for (int i = 0; i < demoList.size(); i++) {
            WebsiteSource site = demoList.get(i);

            // calculateCredibility() → runs TrustedSource's, SuspiciousSource's,
            // or NeutralSource's version depending on the actual type
            site.calculateCredibility();

            System.out.println("  [" + (i + 1) + "] " + site.getClass().getSimpleName()
                    + " — " + site.getUrl());
            System.out.println("      Score: " + site.getCredibilityScore()
                    + " → " + site.classifyScore(site.getCredibilityScore()));
            System.out.println();
        }

        System.out.println("  All objects had the same method CALLED on them,");
        System.out.println("  but each ran its own SUBCLASS version.");
        System.out.println("  That is polymorphism.\n");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MENU OPTION 8 — Search History
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Prompts for a search keyword and prints matching session history entries.
     * Uses CredibilityEngine.printSearchResults() which returns a filtered
     * ArrayList of WebsiteSource objects.
     */
    static void runSearchHistory() {
        System.out.println("\n─── Search Session History ──────────────────");

        if (engine.getAnalysisCount() == 0) {
            System.out.println("  No URLs in session history yet. Check a URL first.");
            return;
        }

        System.out.println("  Enter a keyword to search for (e.g. 'gov', 'cdc', 'xyz'):");
        System.out.print("  > ");
        String query = input.nextLine().trim();

        if (query.isEmpty()) {
            System.out.println("  Search query cannot be empty.");
            return;
        }

        engine.printSearchResults(query);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MENU OPTION 9 — Filter by Credibility Level
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Lets the user filter session history by credibility tier.
     * Options: credible (score >= 60), questionable (40–59), suspicious (< 40).
     */
    static void runFilterHistory() {
        System.out.println("\n─── Filter by Credibility Level ─────────────");

        if (engine.getAnalysisCount() == 0) {
            System.out.println("  No URLs in session history yet. Check a URL first.");
            return;
        }

        System.out.println("  Choose a filter:");
        System.out.println("    1. Credible     (score >= 60)");
        System.out.println("    2. Questionable (score 40–59)");
        System.out.println("    3. Suspicious   (score < 40)");
        System.out.print("  Choice (1–3): ");
        String raw = input.nextLine();
        int choice = validator.validateMenuChoice(raw, 1, 3);

        String filter;
        if (choice == 1) {
            filter = "credible";
        } else if (choice == 2) {
            filter = "questionable";
        } else if (choice == 3) {
            filter = "suspicious";
        } else {
            System.out.println("  Invalid choice. Returning to menu.");
            return;
        }

        engine.printFilteredHistory(filter);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MENU OPTION 10 — Export Session History
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Exports the current session's analysis history to a text file.
     * The user can specify a filename (or press Enter for the default).
     *
     * Demonstrates:
     *   ✦ File I/O using FileManager and PrintWriter
     *   ✦ ArrayList traversal to write each entry
     *   ✦ User input with a default value fallback
     */
    static void runExportHistory() {
        System.out.println("\n─── Export Session History ──────────────────");

        if (engine.getAnalysisCount() == 0) {
            System.out.println("  No URLs in session history to export.");
            return;
        }

        System.out.println("  Enter export filename (or press Enter for default):");
        System.out.print("  > ");
        String raw = input.nextLine().trim();

        String filename = raw.isEmpty() ? "data/export-" + System.currentTimeMillis() + ".txt" : raw;

        if (!filename.endsWith(".txt")) {
            filename = filename + ".txt";
        }

        FileManager exportManager = new FileManager(filename);

        ArrayList<WebsiteSource> history = engine.getHistory();
        for (int i = 0; i < history.size(); i++) {
            exportManager.saveResult(history.get(i));
        }

        System.out.println("\n  Exported " + history.size() + " entries to: " + filename + "\n");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  JSON CLI MODE — used by the Node.js Express web API
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Called when Main is launched with: java -cp out Main --check <url>
     *
     * Validates the URL, runs the credibility engine, saves results to both
     * history files, then prints a single clean JSON object to stdout.
     * The Express API server captures that JSON for the web frontend.
     *
     * KEY: All intermediate System.out.println() calls are redirected to
     * System.err so they don't corrupt the JSON output that Express parses.
     *
     * @param url  the URL to analyze (passed in from args[1], already trimmed)
     */
    static void runJsonCheck(String url) {
        // Inline URL validation
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            System.out.println("{\"error\":\"URL must start with http:// or https://\"}");
            return;
        }

        if (!url.contains(".")) {
            System.out.println("{\"error\":\"URL does not appear to contain a valid domain\"}");
            return;
        }

        // ── Redirect stdout → stderr ──────────────────────────────────────
        //  Any System.out.println inside FileManager, CredibilityEngine, etc.
        //  would corrupt the JSON output. We redirect stdout to stderr for
        //  the duration of the analysis, then restore it just for the JSON.
        java.io.PrintStream originalOut = System.out;
        System.setOut(System.err); // all prints now go to stderr

        // Fresh engine + fileManager for this request (stateless JSON mode)
        CredibilityEngine jsonEngine = new CredibilityEngine();
        FileManager jsonFileManager = new FileManager("data/history.txt");

        // Run analysis (polymorphism happens here)
        WebsiteSource result = jsonEngine.analyze(url);

        // Save to both history files
        jsonFileManager.saveResult(result);
        jsonFileManager.saveResultJson(result);

        // Restore stdout and output ONLY the JSON
        System.setOut(originalOut);
        System.out.println(result.toJson()); // Express reads only this line
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DISPLAY UTILITIES
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Prints the TruthGuard welcome banner.
     * Called once at program start in interactive mode.
     */
    static void printBanner() {
        System.out.println();
        System.out.println("╔════════════════════════════════════════════╗");
        System.out.println("║           TruthGuard v1.0                  ║");
        System.out.println("║   Misinformation Credibility Checker       ║");
        System.out.println("║   AP Computer Science A — Final Project    ║");
        System.out.println("╚════════════════════════════════════════════╝");
        System.out.println();
    }

    /**
     * Prints the interactive main menu.
     * Called at the top of each iteration of the while loop.
     */
    static void printMenu() {
        System.out.println("┌───────────────────────────────────────────┐");
        System.out.println("│               MAIN MENU                   │");
        System.out.println("├───────────────────────────────────────────┤");
        System.out.println("│  ── Core Features ──────────────────────  │");
        System.out.println("│  1.  Check a URL                          │");
        System.out.println("│  2.  View session history                 │");
        System.out.println("│  3.  View saved file history              │");
        System.out.println("│                                           │");
        System.out.println("│  ── Analysis & Search ──────────────────  │");
        System.out.println("│  7.  Statistics dashboard                 │");
        System.out.println("│  8.  Search history by URL                │");
        System.out.println("│  9.  Filter by credibility level          │");
        System.out.println("│  10. Export session history               │");
        System.out.println("│                                           │");
        System.out.println("│  ── AP CSA Demonstrations ─────────────  │");
        System.out.println("│  4.  Run automated test suite             │");
        System.out.println("│  5.  Polymorphism demo                    │");
        System.out.println("│  6.  View suspicious keyword list         │");
        System.out.println("│                                           │");
        System.out.println("│  11. Exit                                 │");
        System.out.println("└───────────────────────────────────────────┘");
        System.out.print("Choose an option (1–11): ");
    }
}
